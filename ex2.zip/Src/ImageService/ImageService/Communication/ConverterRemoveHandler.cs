﻿using ImageService.Communication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.ImageService.Communication
{
    class ConverterRemoveHandler :IConverter
    {
        public void converterExec(IClientHandler ch)
        {

        }
    }
}
