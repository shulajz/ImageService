﻿using ImageService.Communication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.ImageService.Communication
{
    class ConverterLog : IConverter
    {
        public void converterExec(IClientHandler ch)
        {

        }
    }
}
